/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package user_authentication;
import javax.swing.JOptionPane;
/**
 *
 * @author RC_Student_lab
 */
public class User_Authentication {

   // Declaring variables for user data
    static String regUsername;
    static String regPassword;
    static String firstName;
    static String lastName;
    static String contactNumber;

    public static void main(String[] args) {
        collectUserInfo();

        while (!isUsernameValid()) {}
        while (!isPasswordValid()) {}
        while (!isPhoneValid()) {}

        authenticateUser();
    }

    // Collect first and last name
    public static void collectUserInfo() {
        firstName = JOptionPane.showInputDialog("Enter your first name:");
        lastName = JOptionPane.showInputDialog("Enter your last name:");
    }

    // Validate username with a new logic structure
    public static boolean isUsernameValid() {
        regUsername = JOptionPane.showInputDialog("Choose a username (must include '_' and be 5 characters or less):");

        if (regUsername != null && regUsername.contains("_") && regUsername.length() <= 5) {
            JOptionPane.showMessageDialog(null, "Username accepted!");
            return true;
        } else {
            JOptionPane.showMessageDialog(null,
                    "Invalid username.\nUsername must contain an underscore and be no more than 5 characters.");
            return false;
        }
    }

    // Validate password with descriptive pattern explanation
    public static boolean isPasswordValid() {
        String inputPwd = JOptionPane.showInputDialog(
                "Enter a secure password:\n(Min 8 characters, 1 uppercase letter, 1 number, and 1 special character)");

        if (inputPwd != null
                && inputPwd.length() >= 8
                && inputPwd.matches(".*[A-Z].*")
                && inputPwd.matches(".*\\d.*")
                && inputPwd.matches(".*[!@#$%^&*()_+=\\-{}\\[\\]:;\"'<>,.?/\\\\|`~].*")) {

            regPassword = inputPwd;
            JOptionPane.showMessageDialog(null, "Password successfully saved.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null,
                    "Password format incorrect.\nEnsure it contains:\n- Minimum 8 characters\n- One uppercase letter\n- One digit\n- One special character.");
            return false;
        }
    }

    // Validate contact number format
    public static boolean isPhoneValid() {
        contactNumber = JOptionPane.showInputDialog("Enter your mobile number (must begin with +27 and be 12 digits)");

        if (contactNumber != null && contactNumber.startsWith("+27") && contactNumber.length() == 12) {
            JOptionPane.showMessageDialog(null, "Mobile number verified.");
            return true;
        } else {
            JOptionPane.showMessageDialog(null,
                    "Invalid number.\nIt should start with +27 and be exactly 12 characters long.");
            return false;
        }
    }

    // User login logic
    public static void authenticateUser() {
        String inputUser = JOptionPane.showInputDialog("Login - Enter your username:");
        String inputPass = JOptionPane.showInputDialog("Login - Enter your password:");

        if (inputUser != null && inputUser.equals(regUsername)
                && inputPass != null && inputPass.equals(regPassword)) {

            JOptionPane.showMessageDialog(null, "Welcome back, " + firstName + " " + lastName + "!");
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Incorrect username or password.");
            authenticateUser(); // Retry login
        }
    }
}

    

    
    

